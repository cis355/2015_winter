<?php
session_start();
echo $_SESSION['ID'] . "<br>" . $_SESSION['PersonID'] . "<br>";
echo date('Y-m-d H:i:s','1299762201428');